import express from 'express';
import data from './data.js';
import  bodyparser from'body-parser';
import cors from 'cors';

const app =express();

//cors
app.use(cors({
    origin: '*'
}));

//Body parser for middleware
app.use(bodyparser.urlencoded({extended:false}));
app.use(bodyparser.json());

app.get('/api/products', (req,res) =>{
    res.send(data.products)
    console.log(data.products,"products")
})
  


//Port listenning 5000
const port = process.env.PORT || 5000;
app.listen(port, () =>{
    console.log(`Succesfully server started on ${port}`)
})
